# user.py
class User:
    def __init__(self, name, user_id, books_owned=None):
        self.name = name
        self.user_id = user_id
        self.books_owned = books_owned if books_owned else []

    def add_book(self, book_id):
        if book_id not in self.books_owned:
            self.books_owned.append(book_id)

    def remove_book(self, book_id):
        if book_id in self.books_owned:
            self.books_owned.remove(book_id)