import json
import os
from book import Book
from user import User

DATA_FILE = "library_data.json"


def load_data():
    """Wczytuje dane z pliku JSON przy starcie aplikacji"""
    if not os.path.exists(DATA_FILE):
        return [], []  # Zwróć puste listy jeśli plik nie istnieje

    try:
        with open(DATA_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)

            # Tworzenie obiektów User z danych
            users = []
            for user_data in data['users']:
                user = User(
                    name=user_data['name'],
                    user_id=user_data['user_id']
                )
                user.books_owned = user_data.get('books_owned', [])
                users.append(user)

            # Tworzenie obiektów Book z danych
            books = []
            for book_data in data['books']:
                book = Book(
                    title=book_data['title'],
                    author=book_data['author'],
                    book_id=book_data['book_id'],
                    genre=book_data['genre'],
                    owner_id=book_data['owner_id']
                )
                book.status = book_data.get('status', 'available')
                books.append(book)

            return users, books

    except (FileNotFoundError, json.JSONDecodeError) as e:
        print(f"Błąd wczytywania danych: {e}")
        return [], []


def save_data(users, books):
    """Zapisuje dane do pliku JSON przed zamknięciem aplikacji"""
    data = {
        'users': [{
            'name': user.name,
            'user_id': user.user_id,
            'books_owned': user.books_owned
        } for user in users],

        'books': [{
            'title': book.title,
            'author': book.author,
            'book_id': book.book_id,
            'genre': book.genre,
            'owner_id': book.owner_id,
            'status': book.status
        } for book in books]
    }

    try:
        with open(DATA_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    except IOError as e:
        print(f"Błąd zapisu danych: {e}")