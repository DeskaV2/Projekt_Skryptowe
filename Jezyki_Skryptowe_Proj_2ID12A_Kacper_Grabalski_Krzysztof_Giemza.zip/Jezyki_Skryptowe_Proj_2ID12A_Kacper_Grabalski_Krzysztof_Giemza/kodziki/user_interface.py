from storage import save_data
from user import User
from book import Book


def main_menu(users, books):
    while True:
        print("\n=== Lokalna Sieć Wymiany Książek ===")
        print("1. Dodaj użytkownika")
        print("2. Dodaj książkę")
        print("3. Wyszukaj książki")
        print("4. Wymień książkę")
        print("5. Wyświetl statystyki i użytkowników")
        print("6. Wyszukaj użytkownika")
        print("7. Wyjście")

        choice = input("Wybierz opcję: ")

        if choice == "1":
            add_user(users, books)
        elif choice == "2":
            add_book(users, books)
        elif choice == "3":
            search_books(books)
        elif choice == "4":
            exchange_book(users, books)
        elif choice == "5":
            display_stats(users, books)
        elif choice == "6":
            search_users(users)
        elif choice == "7":
            break
        else:
            print("Nieprawidłowy wybór!")


def add_user(users, books):
    name = input("Imię i nazwisko: ")
    user_id = max([u.user_id for u in users], default=0) + 1
    users.append(User(name, user_id))
    save_data(users, books)
    print(f"Utworzono użytkownika: {name} (ID: {user_id})")


def add_book(users, books):
    try:
        user_id = int(input("ID właściciela: "))
    except ValueError:
        print("Nieprawidłowy format ID!")
        return

    # Znajdź użytkownika
    user = next((u for u in users if u.user_id == user_id), None)
    if user is None:
        print("Nieznany użytkownik!")
        return

    title = input("Tytuł: ")
    author = input("Autor: ")
    genre = input("Gatunek: ")
    book_id = max([b.book_id for b in books], default=0) + 1

    # Utwórz książkę i dodaj do listy
    new_book = Book(title, author, book_id, genre, user_id)
    books.append(new_book)

    # Dodaj książkę do użytkownika
    user.add_book(book_id)

    save_data(users, books)
    print(f"Dodano książkę: {title} (ID: {book_id}) dla użytkownika {user.name}")

def search_books(books):
    term = input("Szukaj (tytuł/autor/gatunek): ").lower()
    found_books = list(filter(lambda b: term in b.title.lower()
                                        or term in b.author.lower()
                                        or term in b.genre.lower(), books))

    if not found_books:
        print("Brak wyników!")
        return

    print("\nZnalezione książki:")
    for book in found_books:
        print(f"{book.title} - {book.author} ({book.genre})")


def display_stats(users, books):
    genres = [b.genre for b in books]
    unique_genres = set(genres)

    print("\n=== Statystyki biblioteki ===")
    print(f"Łączna liczba książek: {len(books)}")
    print(f"Liczba gatunków: {len(unique_genres)}")

    # Książki per gatunek
    genre_count = {genre: genres.count(genre) for genre in unique_genres}
    print("\nKsiążki per gatunek:")
    for genre, count in genre_count.items():
        print(f"- {genre}: {count}")

    # Lista użytkowników
    print("\n=== Zarejestrowani użytkownicy ===")
    print(f"Liczba użytkowników: {len(users)}")
    print("\nLista użytkowników:")
    for user in users:
        print(f"ID: {user.user_id}, Imię i nazwisko: {user.name}")


def search_users(users):
    print("\n=== Wyszukiwanie użytkowników ===")
    term = input("Wprowadź imię, nazwisko lub ID: ").lower()

    # Próba konwersji na ID jeśli wprowadzono liczbę
    try:
        search_id = int(term)
    except ValueError:
        search_id = None

    found_users = []
    for user in users:
        # Sprawdzanie czy pasuje do imienia/nazwiska lub ID
        if term in user.name.lower() or user.user_id == search_id:
            found_users.append(user)

    if not found_users:
        print("Nie znaleziono użytkowników.")
        return

    print("\nZnalezieni użytkownicy:")
    for user in found_users:
        print(f"ID: {user.user_id}, Imię i nazwisko: {user.name}")
        if user.books_owned:
            print(f"  Posiadane książki: {len(user.books_owned)}")
        else:
            print("  Brak książek")

def exchange_book(users, books):
    print("\n=== Wymiana książek ===")

    # Krok 1: Użytkownik A
    try:
        user_a_id = int(input("Podaj ID użytkownika A (oddającego książkę): "))
    except ValueError:
        print("Nieprawidłowe ID.")
        return

    user_a = next((u for u in users if u.user_id == user_a_id), None)
    if user_a is None:
        print("Nie znaleziono użytkownika o podanym ID.")
        return

    # Krok 2: Pobierz książki użytkownika A
    user_a_books = [b for b in books if b.owner_id == user_a_id]
    if not user_a_books:
        print("Użytkownik nie posiada żadnych książek.")
        return

    print("Książki użytkownika A:")
    for book in user_a_books:
        print(f"ID: {book.book_id}, Tytuł: {book.title}, Autor: {book.author}")

    # Krok 3: Wybór książki od użytkownika A
    try:
        book_a_id = int(input("Podaj ID książki do oddania: "))
    except ValueError:
        print("Nieprawidłowe ID książki.")
        return

    book_a = next((b for b in user_a_books if b.book_id == book_a_id), None)
    if book_a is None:
        print("Nieprawidłowe ID książki.")
        return

    # Krok 4: Użytkownik B
    try:
        user_b_id = int(input("Podaj ID użytkownika B (którego książkę chcesz otrzymać): "))
    except ValueError:
        print("Nieprawidłowe ID.")
        return

    user_b = next((u for u in users if u.user_id == user_b_id), None)
    if user_b is None:
        print("Nie znaleziono użytkownika B.")
        return

    # Krok 5: Pobierz książki użytkownika B
    user_b_books = [b for b in books if b.owner_id == user_b_id]
    if not user_b_books:
        print("Użytkownik B nie posiada żadnych książek.")
        return

    print("Książki użytkownika B:")
    for book in user_b_books:
        print(f"ID: {book.book_id}, Tytuł: {book.title}, Autor: {book.author}")

    # Krok 6: Wybór książki od użytkownika B
    try:
        book_b_id = int(input("Podaj ID książki, którą chcesz otrzymać: "))
    except ValueError:
        print("Nieprawidłowe ID książki.")
        return

    book_b = next((b for b in user_b_books if b.book_id == book_b_id), None)
    if book_b is None:
        print("Nieprawidłowe ID książki.")
        return

    # Po znalezieniu użytkownika A, wyświetl jego książki
    print(f"\nUżytkownik: {user_a.name} (ID: {user_a.user_id})")
    user_a_books = [b for b in books if b.owner_id == user_a_id]

    if not user_a_books:
        print("Użytkownik nie posiada żadnych książek.")
        return

    print("Posiadane książki:")
    for book in user_a_books:
        print(f"ID: {book.book_id}, Tytuł: {book.title}, Autor: {book.author}")

    # Krok 7: Wymiana
    # Zmiana właścicieli
    book_a.owner_id = user_b_id
    book_b.owner_id = user_a_id

    # Aktualizacja list książek użytkowników
    if book_a.book_id in user_a.books_owned:
        user_a.books_owned.remove(book_a.book_id)
    user_b.books_owned.append(book_a.book_id)

    if book_b.book_id in user_b.books_owned:
        user_b.books_owned.remove(book_b.book_id)
    user_a.books_owned.append(book_b.book_id)

    print(f"\nWymiana zakończona sukcesem!")
    print(f"Użytkownik {user_a.name} otrzymał: {book_b.title}")
    print(f"Użytkownik {user_b.name} otrzymał: {book_a.title}")