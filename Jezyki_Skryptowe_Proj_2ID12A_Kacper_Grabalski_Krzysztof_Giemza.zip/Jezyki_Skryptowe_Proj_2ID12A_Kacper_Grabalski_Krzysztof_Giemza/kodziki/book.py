# book.py
class Book:
    def __init__(self, title, author, book_id, genre, owner_id):
        self.title = title
        self.author = author
        self.book_id = book_id
        self.genre = genre
        self.owner_id = owner_id
        self.status = "available"

    def change_status(self, new_status):
        self.status = new_status