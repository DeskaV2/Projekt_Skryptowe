# visualization.py
import matplotlib.pyplot as plt
from collections import Counter
from utils import log_activity  # Dodaj ten import


@log_activity
def generate_genre_chart(books):
    if not books:
        print("Brak danych do wizualizacji!")
        return

    genres = [book.genre for book in books]
    genre_count = Counter(genres)

    plt.figure(figsize=(10, 6))
    plt.bar(genre_count.keys(), genre_count.values())
    plt.title("Rozkład książek według gatunków")
    plt.xlabel("Gatunek")
    plt.ylabel("Liczba książek")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig("books_genre_chart.png")
    print("Zapisano wykres do pliku: books_genre_chart.png")