from storage import load_data, save_data
from user_interface import main_menu
from visualization import generate_genre_chart


def main():
    # Wczytanie danych przy starcie aplikacji
    users, books = load_data()

    # Uruchomianie menu
    main_menu(users, books)

    # Zapis dane przed wyjściem z aplikacji
    save_data(users, books)
    generate_genre_chart(books)
    print("Dane zostały zapisane. Do widzenia!")


if __name__ == "__main__":
    main()