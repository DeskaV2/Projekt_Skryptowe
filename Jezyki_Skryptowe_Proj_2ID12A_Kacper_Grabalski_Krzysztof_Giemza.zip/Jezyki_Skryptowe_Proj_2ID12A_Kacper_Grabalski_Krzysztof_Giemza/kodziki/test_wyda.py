# test_performance.py
import timeit
import os
from storage import save_data, load_data
from user import User
from book import Book


def setup_data(num_users=100, num_books=1000):
    users = [User(f"User{i}", i) for i in range(num_users)]
    books = [Book(f"Book{i}", f"Author{i}", i, "Genre", i % num_users) for i in range(num_books)]
    for i, user in enumerate(users):
        user.books_owned = [j for j in range(num_books) if j % num_users == i]
    return users, books


def test_save():
    users, books = setup_data()
    save_data(users, books)


def test_load():
    load_data()


if __name__ == '__main__':
    # Przygotuj dane
    users, books = setup_data()
    save_data(users, books)

    # Test zapisu
    save_time = timeit.timeit("test_save()", setup="from __main__ import test_save", number=10)
    print(f"Średni czas zapisu: {save_time / 10:.4f}s")

    # Test odczytu
    load_time = timeit.timeit("test_load()", setup="from __main__ import test_load", number=10)
    print(f"Średni czas odczytu: {load_time / 10:.4f}s")

    # Test dużej ilości danych
    users, books = setup_data(1000, 10000)
    save_data(users, books)

    large_load_time = timeit.timeit("test_load()", setup="from __main__ import test_load", number=5)
    print(f"Średni czas odczytu dużej ilości danych: {large_load_time / 5:.4f}s")