# test_memory.py
from memory_profiler import profile
import os
import tempfile
import shutil
import storage
from storage import save_data, load_data


@profile
def memory_test():
    # Utwórz tymczasowy katalog
    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, "memory_test_data.json")

    try:
        # Ustaw plik testowy
        original_data_file = storage.DATA_FILE
        storage.DATA_FILE = test_file

        # Tworzenie danych
        from user import User
        from book import Book
        num_users = 500
        num_books = 5000
        users = [User(f"User{i}", i) for i in range(num_users)]
        books = [Book(f"Book{i}", f"Author{i}", i, "Genre", i % num_users) for i in range(num_books)]

        # Dodawanie książek do użytkowników
        for i, user in enumerate(users):
            user.books_owned = [j for j in range(num_books) if j % num_users == i]

        # Zapis i odczyt
        save_data(users, books)
        loaded_users, loaded_books = load_data()

        # Czyszczenie
        del loaded_users
        del loaded_books

    finally:
        # Przywróć oryginalny plik danych
        storage.DATA_FILE = original_data_file
        # Usuń tymczasowy katalog
        shutil.rmtree(test_dir)


if __name__ == '__main__':
    memory_test()