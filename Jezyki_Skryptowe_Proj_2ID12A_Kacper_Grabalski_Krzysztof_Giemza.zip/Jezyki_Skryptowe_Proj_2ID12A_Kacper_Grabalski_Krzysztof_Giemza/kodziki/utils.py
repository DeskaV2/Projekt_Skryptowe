# utils.py
import re
def input_with_validation(prompt, pattern):
    """Funkcja walidująca dane wejściowe"""
    while True:
        value = input(prompt)
        if re.match(pattern, value):
            return value
        print("Nieprawidłowy format!")

def recursive_factorial(n):
    """Rekurencyjne obliczanie silni"""
    if n == 0:
        return 1
    return n * recursive_factorial(n-1)

# Dekorator do logowania
def log_activity(func):
    def wrapper(*args, **kwargs):
        print(f"Wywołano: {func.__name__}")
        return func(*args, **kwargs)
    return wrapper