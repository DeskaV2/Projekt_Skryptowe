# test_functional.py
import unittest
from unittest.mock import patch, MagicMock
import main  # Importujemy główny moduł


class TestFunctional(unittest.TestCase):
    @patch('builtins.input', side_effect=['7'])
    def test_main_menu_exit(self, mock_input):
        # Utwórz mocki dla zależności
        mock_load = MagicMock(return_value=([], []))
        mock_save = MagicMock()
        mock_chart = MagicMock()

        # Podmień oryginalne funkcje mockami
        with patch('main.load_data', mock_load), \
                patch('main.save_data', mock_save), \
                patch('main.generate_genre_chart', mock_chart):
            # Uruchom główną funkcję
            main.main()

            # Sprawdź wywołania
            mock_load.assert_called_once()
            mock_save.assert_called_once_with([], [])
            mock_chart.assert_called_once_with([])


if __name__ == "__main__":
    unittest.main()