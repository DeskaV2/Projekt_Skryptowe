# test_units.py
import unittest
from book import Book
from user import User


class TestLibrary(unittest.TestCase):
    def test_book_creation(self):
        book = Book("Python Basics", "A. Smith", 1, "Programming", 101)
        self.assertEqual(book.title, "Python Basics")

    def test_user_add_book(self):
        user = User("John Doe", 101)
        user.add_book(201)
        self.assertIn(201, user.books_owned)


if __name__ == "__main__":
    unittest.main()