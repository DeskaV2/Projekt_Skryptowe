# test_boundary.py
import unittest
import os
from storage import save_data, load_data
from user import User
from book import Book


class TestBoundary(unittest.TestCase):
    TEST_DATA_FILE = "test_boundary_data.json"

    def setUp(self):
        import storage
        self.original_data_file = storage.DATA_FILE
        storage.DATA_FILE = self.TEST_DATA_FILE
        if os.path.exists(self.TEST_DATA_FILE):
            os.remove(self.TEST_DATA_FILE)

    def tearDown(self):
        import storage
        storage.DATA_FILE = self.original_data_file
        if os.path.exists(self.TEST_DATA_FILE):
            os.remove(self.TEST_DATA_FILE)

    def test_large_data(self):
        # Tworzenie dużej ilości danych
        num_users = 1000
        num_books = 10000

        users = []
        for i in range(num_users):
            users.append(User(f"User{i}", i))

        books = []
        for i in range(num_books):
            owner_id = i % num_users
            books.append(Book(f"Book{i}", f"Author{i}", i, "Genre", owner_id))
            users[owner_id].add_book(i)

        # Zapis i odczyt
        save_data(users, books)
        loaded_users, loaded_books = load_data()

        # Sprawdź poprawność
        self.assertEqual(len(loaded_users), num_users)
        self.assertEqual(len(loaded_books), num_books)
        self.assertEqual(len(loaded_users[0].books_owned), num_books // num_users)

    def test_special_characters(self):
        # Testowanie specjalnych znaków
        user = User("Zażółć gęślą jaźń", 1)
        book = Book("Książka z € & # @", "Автор Їжак", 1, "Gatunek", 1)

        save_data([user], [book])
        loaded_users, loaded_books = load_data()

        self.assertEqual(loaded_users[0].name, "Zażółć gęślą jaźń")
        self.assertEqual(loaded_books[0].title, "Książka z € & # @")
        self.assertEqual(loaded_books[0].author, "Автор Їжак")


if __name__ == '__main__':
    unittest.main()