# test_integration.py
import unittest
import os
import json
from main import main
from storage import load_data, save_data
from user import User
from book import Book
from unittest.mock import patch


class TestIntegration(unittest.TestCase):
    TEST_DATA_FILE = "test_library_data.json"

    def setUp(self):
        # Ustaw plik testowy
        self.original_data_file = "library_data.json"
        import storage
        storage.DATA_FILE = self.TEST_DATA_FILE

        # Usuń plik testowy jeśli istnieje
        if os.path.exists(self.TEST_DATA_FILE):
            os.remove(self.TEST_DATA_FILE)

    def tearDown(self):
        # Przywróć oryginalny plik danych
        import storage
        storage.DATA_FILE = self.original_data_file
        # Usuń plik testowy
        if os.path.exists(self.TEST_DATA_FILE):
            os.remove(self.TEST_DATA_FILE)

    def test_full_flow(self):
        # Symuluj interakcję użytkownika
        inputs = [
            '1',  # Dodaj użytkownika
            'Jan Kowalski',
            '2',  # Dodaj książkę
            '1',  # ID właściciela
            'Python dla poczatkujacych',
            'Marek Nowak',
            'Programowanie',
            '2',  # Dodaj kolejną książkę
            '1',  # ID właściciela
            'Python zaawansowany',
            'Jan Nowak',
            'Programowanie',
            '5',  # Wyświetl statystyki
            '7'  # Wyjście
        ]

        with patch('builtins.input', side_effect=inputs):
            main()

        # Sprawdź dane w pliku
        with open(self.TEST_DATA_FILE, 'r') as f:
            data = json.load(f)

            # Sprawdź użytkowników
            self.assertEqual(len(data['users']), 1)
            self.assertEqual(data['users'][0]['name'], 'Jan Kowalski')

            # Sprawdź książki
            self.assertEqual(len(data['books']), 2)
            titles = [book['title'] for book in data['books']]
            self.assertIn('Python dla poczatkujacych', titles)
            self.assertIn('Python zaawansowany', titles)

    def test_exchange_flow(self):
        # Przygotuj dane testowe
        user1 = User("Jan Kowalski", 1)
        user2 = User("Anna Nowak", 2)
        book1 = Book("Ksiazka A", "Autor A", 101, "Gatunek A", 1)
        book2 = Book("Ksiazka B", "Autor B", 102, "Gatunek B", 2)

        save_data([user1, user2], [book1, book2])

        # Symuluj wymianę
        inputs = [
            '4',  # Wymień książkę
            '1',  # ID użytkownika A
            '101',  # ID książki do oddania
            '2',  # ID użytkownika B
            '102',  # ID książki do otrzymania
            '7'  # Wyjście
        ]

        with patch('builtins.input', side_effect=inputs):
            main()

        # Sprawdź dane po wymianie
        users, books = load_data()

        # Sprawdź właścicieli książek
        book1_owner = next((b.owner_id for b in books if b.book_id == 101), None)
        book2_owner = next((b.owner_id for b in books if b.book_id == 102), None)

        self.assertEqual(book1_owner, 2)
        self.assertEqual(book2_owner, 1)

        # Sprawdź listy książek użytkowników
        user1_books = next((u.books_owned for u in users if u.user_id == 1), [])
        user2_books = next((u.books_owned for u in users if u.user_id == 2), [])

        self.assertIn(102, user1_books)
        self.assertNotIn(101, user1_books)
        self.assertIn(101, user2_books)
        self.assertNotIn(102, user2_books)


if __name__ == '__main__':
    unittest.main()